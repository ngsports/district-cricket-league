DISTRICT CRICKET LEAGUE 2026–27 — STARTER PROJECT

Files
- index.html: responsive black-and-gold website starter
- payment-qr.jpeg: QR image supplied by the user

WHAT WORKS
- Mobile-friendly layout
- Player registration fields and browser-side validation
- Demo confirmation message
- All-caps affiliation line at the top
- The supplied QR image is displayed in the payment section

DEMO ONLY / NOT CONNECTED
- Registration form does NOT send or save entries
- No admin login/dashboard
- QR display does not verify payments
- No payment gateway, email/SMS notifications or document uploads

FREE PUBLISHING WITH GITHUB PAGES (iPhone)
1. Sign in/create an account at https://github.com/
2. Create a repository, e.g. dcl-2026-27
3. Upload BOTH index.html and payment-qr.jpeg to the same repository root.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for the Pages URL to appear in Settings > Pages. Test it on your phone.

IMPORTANT ABOUT THE QR
- The image is shown as supplied; this project has not verified the QR's destination or payee.
- Before publishing, scan it using a trusted UPI app and verify the displayed recipient/account name with the authorized league organizer.
- Confirm the ₹10,000 fee and any claimed association affiliation with the authorized organizers before collecting money.
- A static QR does not automatically prove a payment was made. Verify transactions separately or integrate a supported payment gateway/backend.
- Never ask players to share their UPI PIN or OTP.

REAL REGISTRATION
- To collect registrations without paid hosting, create a Google Form and link/embed it on the website. Responses can be saved in its Responses tab / linked Google Sheet.
- Keep the response spreadsheet private. This HTML form is a demo until connected to Google Forms or a suitable backend.
